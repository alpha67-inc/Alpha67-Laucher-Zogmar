eel.expose(returnInfo);
function returnInfo(){
    var select = document.getElementById('versiong');
    var value = select.options[select.selectedIndex].value;
    alert(value) // en
    return value;
}

eel.expose(js_random);
function js_random() {
  return Math.random();
}


async function run() {
    eel.prints()(function(settings){
        var version = settings;
        alert(version)

          });
}


eel.sendVersions()(function(settings){
    var version = settings;
    var select = document.getElementById("versiong"); 
  
  
    
    // Optional: Clear all existing options first:
    select.innerHTML = "";
    // Populate list with options:
    for(var i = 0; i < version.length; i++) {
        var opt = version[i];
        select.innerHTML += "<option value=\"" + opt + "\">" + opt + "</option>";
    }
      });
